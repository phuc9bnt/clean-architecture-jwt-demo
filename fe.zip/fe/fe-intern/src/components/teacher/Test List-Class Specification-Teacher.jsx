import React, { useState } from "react";
import "./TestsList.css";
import { FaBook, FaBell, FaHeadset, FaCog, FaSignOutAlt, FaTimes, FaEllipsisV } from "react-icons/fa";
import { Link } from "react-router-dom";

const TestsList = () => {
  const [showNotifications, setShowNotifications] = useState(false);

  const notifications = [
    { id: 1, name: "Lê Thị Mỹ A", message: "" },
    { id: 2, name: "Nguyễn Văn Xương", message: "đã trả lời ticket của bạn" }
  ];

  const toggleNotifications = () => {
    setShowNotifications(prev => !prev);
  };

  const data = [
    { id: "HS001", name: "Nguyễn Văn A", test15p: 8, homework5: 9, homework4: 10, homework3: 7, homework2: 6, homework1: 8 },
    { id: "HS002", name: "Trần Thị B", test15p: 7, homework5: 8, homework4: 9, homework3: 6, homework2: 7, homework1: 9 },
    { id: "HS003", name: "Lê Văn C", test15p: 9, homework5: 9, homework4: 8, homework3: 8, homework2: 7, homework1: 10 },
  ];

  return (
    <div className="testslist-body">
      <div className="sidebar">
        <div className="logo">
          <img src="images/logo.jpg" alt="Logo" className="logo-image" />
        </div>
        <div className="settings-icon">
          <FaCog className="function-icon" />
        </div>
        <div className="function-icons">
          <Link to="/addnewtest1" className="icon-item active">
            <FaBook className="function-icon" />
            <p className="icon-description">Môn học</p>
          </Link>
          <Link to="/support" className="icon-item">
            <FaHeadset className="function-icon" />
            <p className="icon-description">Hỗ trợ</p>
          </Link>
          <div className="icon-item" onClick={toggleNotifications}>
            <FaBell className="function-icon" />
            <p className="icon-description">Thông báo</p>
          </div>
          <Link to="/logout" className="icon-item">
            <FaSignOutAlt className="function-icon" />
            <p className="icon-description">Đăng xuất</p>
          </Link>
        </div>
      </div>

      <div className="main-content">
        <div className="header">
          <h1 className="title">4A1</h1>
          <div className="search-wrapper">
            <input type="text" className="search-input" placeholder="Tìm kiếm học sinh..." />
            <FaCog className="search-icon" />
          </div>
        </div>

        <div className="table-container">
          <table className="table-kho-de">
            <thead>
              <tr>
                <th>ID</th>
                <th>Họ Và Tên</th>
                <th>Kiểm tra 15 phút</th>
                <th>Bài tập về nhà buổi 5</th>
                <th>Bài tập về nhà buổi 4</th>
                <th>Bài tập về nhà buổi 3</th>
                <th>Bài tập về nhà buổi 2</th>
                <th>Bài tập về nhà buổi 1</th>
              </tr>
            </thead>
            <tbody>
              {data.map((row) => (
                <tr key={row.id}>
                  <td>{row.id}</td>
                  <td>{row.name}</td>
                  <td>{row.test15p}</td>
                  <td>{row.homework5}</td>
                  <td>{row.homework4}</td>
                  <td>{row.homework3}</td>
                  <td>{row.homework2}</td>
                  <td>{row.homework1}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="pagination">
          <button className="page-btn active">1</button>
          <button className="page-btn">2</button>
          <button className="page-btn">3</button>
          <span className="dots">...</span>
          <button className="page-btn">6</button>
        </div>
      </div>

      <div className={`notification-box ${showNotifications ? "show" : "hide"}`}>
        <div className="notification-header">
          <span>Thông Báo</span>
          <FaTimes className="close-btn" onClick={toggleNotifications} />
        </div>
        <div className="notification-content">
          {notifications.length > 0 ? (
            notifications.map((item) => (
              <div className="notification-item" key={item.id}>
                <span className="user-icon"></span>
                <div className="notification-text">
                  <strong>{item.name}</strong>
                  <p>{item.message}</p>
                </div>
                <FaEllipsisV className="notification-options" />
              </div>
            ))
          ) : (
            <p>Không có thông báo mới.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default TestsList;
