import React, { useState, useEffect } from "react";
import axios from "axios";
import "./cc.css";
import { FaBook, FaBell, FaHeadset, FaCog, FaPlus, FaSignOutAlt, FaTimes, FaEllipsisV, FaChevronLeft, FaChevronRight } from "react-icons/fa";
import { Link } from "react-router-dom";

const Testslist = () => {
  // State để điều khiển hiển thị thông báo
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  
  // Thêm state cho dữ liệu bảng
  const [tests, setTests] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [searchTerm, setSearchTerm] = useState("");
  
  // Cố định số lượng mỗi trang
  const pageSize = 4;
  
  // Toggle hiển thị hộp thông báo
  const toggleNotifications = () => {
    setShowNotifications(prev => !prev);
  };
  
  // Hàm lấy dữ liệu bài kiểm tra với phân trang
  const fetchTests = async (pageNumber = 1) => {
    setIsLoading(true);
    try {
      const response = await axios.get(`http://localhost:5026/api/Quiz`);
      const responseData = response.data;
      setTests(responseData.tests || []);
      
      // Tính toán tổng số trang từ totalCount và pageSize
      const calculatedTotalPages = Math.ceil(responseData.totalCount / pageSize);
      setTotalPages(calculatedTotalPages || 1);
      setCurrentPage(responseData.pageNumber || 1);
      
      // Lưu dữ liệu vào localStorage để có thể tìm kiếm offline
      localStorage.setItem("tests", JSON.stringify(responseData.tests || []));
      localStorage.setItem("totalTests", responseData.totalCount);
    } catch (error) {
      console.error("Lỗi khi lấy dữ liệu bài kiểm tra:", error);
      
      // Nếu không kết nối được với API, thử lấy dữ liệu từ localStorage
      const cachedTests = localStorage.getItem("tests");
      if (cachedTests) {
        setTests(JSON.parse(cachedTests));
        const totalCount = localStorage.getItem("totalTests") || 10;
        setTotalPages(Math.ceil(Number(totalCount) / pageSize));
        console.log("Đã tải dữ liệu bài kiểm tra từ localStorage");
      }
    } finally {
      setIsLoading(false);
    }
  };
  
  // Lấy dữ liệu thông báo
  const fetchNotifications = async () => {
    try {
      const response = await axios.get("http://localhost:5026/api/Notification");
      const notificationData = response.data;
      setNotifications(notificationData);
      localStorage.setItem("notifications", JSON.stringify(notificationData));
    } catch (error) {
      console.error("Lỗi khi lấy dữ liệu thông báo:", error);
      // Sử dụng dữ liệu từ localStorage nếu có
      const cachedNotifications = localStorage.getItem("notifications");
      if (cachedNotifications) {
        setNotifications(JSON.parse(cachedNotifications));
      }
    }
  };
  
  // Xử lý tìm kiếm
  const handleSearch = async () => {
    if (!searchTerm.trim()) {
      fetchTests(1);
      return;
    }
    
    setIsLoading(true);
    try {
      const response = await axios.get(`http://localhost:5026/Tests/Search?query=${searchTerm}`);
      setTests(response.data || []);
      setTotalPages(1); // Khi tìm kiếm, hiện tại chỉ hiển thị 1 trang kết quả
    } catch (error) {
      console.error("Lỗi khi tìm kiếm:", error);
    } finally {
      setIsLoading(false);
    }
  };
  
  // Hàm format ngày tháng dạng dd/mm/yyyy
  const formatDate = (dateString) => {
    if (!dateString) return '';
    
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('vi-VN', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
      }).replace(/\//g, '/');
    } catch (error) {
      return dateString;
    }
  };
  
  // Xử lý khi người dùng thay đổi trang
  const handlePageChange = (pageNumber) => {
    if (pageNumber < 1 || pageNumber > totalPages) return;
    setCurrentPage(pageNumber);
    fetchTests(pageNumber);
  };
  
  // Tạo mảng số trang cho phân trang
  const getPageNumbers = (currentPage, totalPages) => {
    // Nếu tổng số trang <= 5, hiển thị tất cả các trang
    if (totalPages <= 5) {
      return Array.from({ length: totalPages }, (_, i) => i + 1);
    }
    
    // Nếu đang ở gần đầu, hiển thị 5 trang đầu
    if (currentPage <= 3) {
      return [1, 2, 3, 4, 5];
    }
    
    // Nếu đang ở gần cuối, hiển thị 5 trang cuối
    if (currentPage >= totalPages - 2) {
      return Array.from({ length: 5 }, (_, i) => totalPages - 4 + i);
    }
    
    // Nếu ở giữa, hiển thị trang hiện tại và 2 trang trước, 2 trang sau
    return [currentPage - 2, currentPage - 1, currentPage, currentPage + 1, currentPage + 2];
  };
  
  // Xử lý khi user nhấn Enter trong ô tìm kiếm
  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };
  
  // Xử lý redirect đến trang tạo bài kiểm tra mới
  const handleAddNew = () => {
    window.location.href = '/addnewtest1';
  };
  
  // Gọi API khi component mount
  useEffect(() => {
    fetchTests(1);
    fetchNotifications();
  }, []);
  
  return (
    <div className="testslist-body">
      <div className="sidebar">
        <div className="logo">
          <img src="images/logo.jpg" alt="Logo" className="logo-image" />
        </div>
        <div className="settings-icon">
          <FaCog className="function-icon" />
        </div>
        <div className="function-icons">
          <Link to="/addnewtest1" className="icon-item active">
            <FaBook className="function-icon" />
            <p className="icon-description">Môn học</p>
          </Link>
          <Link to="/support" className="icon-item">
            <FaHeadset className="function-icon" />
            <p className="icon-description">Hỗ trợ</p>
          </Link>
          <div className="icon-item" onClick={toggleNotifications}>
            <FaBell className="function-icon" />
            <p className="icon-description">Thông báo</p>
          </div>
          <Link to="/logout" className="icon-item">
            <FaSignOutAlt className="function-icon" />
            <p className="icon-description">Đăng xuất</p>
          </Link>
        </div>
      </div>

      {/* Main Content */}
      <div className="main-content">
        {/* Header */}
        <div className="header">
          <h1 className="title">Kho Đề</h1>
          <div className="search-wrapper">
            <input 
              type="text" 
              className="search-input" 
              placeholder="Tìm kiếm đề..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyPress={handleKeyPress}
            />
            <FaCog className="search-icon" onClick={handleSearch} />
          </div>
          <button className="add-btn" onClick={handleAddNew}>
            <FaPlus />
          </button>
        </div>

        {/* Table */}
        {isLoading ? (
          <div className="loading">Đang tải dữ liệu...</div>
        ) : (
          <div className="table-container">
            <table className="table-kho-de">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Tiêu Đề</th>
                  <th>Ngày Hết Hạn</th>
                  <th>Thời Lượng</th>
                  <th>Thời Gian Giới Hạn</th>
                </tr>
              </thead>
              <tbody>
                {tests.length > 0 ? (
                  tests.map((test, index) => (
                    <tr key={index}>
                      <td>{test.id}</td>
                      <td>{test.title}</td>
                      <td>{formatDate(test.expiryDate)}</td>
                      <td>{test.duration} phút</td>
                      <td>{test.timeLimit} phút</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="5" style={{textAlign: "center"}}>Không có dữ liệu bài kiểm tra</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination */}
        <div className="pagination">
          {/* Nút quay lại trang trước */}
          <button 
            className="page-btn" 
            disabled={currentPage === 1}
            onClick={() => handlePageChange(currentPage - 1)}
          >
            <FaChevronLeft />
          </button>
          
          {/* Nút trang đầu tiên nếu không hiển thị trong danh sách */}
          {currentPage > 3 && totalPages > 5 && (
            <>
              <button
                className="page-btn"
                onClick={() => handlePageChange(1)}
              >
                1
              </button>
              <span className="dots">...</span>
            </>
          )}
          
          {/* Các nút số trang */}
          {getPageNumbers(currentPage, totalPages).map(pageNumber => (
            <button
              key={pageNumber}
              className={`page-btn ${currentPage === pageNumber ? "active" : ""}`}
              onClick={() => handlePageChange(pageNumber)}
            >
              {pageNumber}
            </button>
          ))}
          
          {/* Hiển thị ... và nút trang cuối nếu cần */}
          {currentPage < totalPages - 2 && totalPages > 5 && (
            <>
              <span className="dots">...</span>
              <button 
                className="page-btn"
                onClick={() => handlePageChange(totalPages)}
              >
                {totalPages}
              </button>
            </>
          )}
          
          {/* Nút chuyển trang tiếp theo */}
          <button 
            className="page-btn" 
            disabled={currentPage === totalPages}
            onClick={() => handlePageChange(currentPage + 1)}
          >
            <FaChevronRight />
          </button>
        </div>
      </div>

      {/* Hộp Thông Báo */}
      <div className={`notification-box ${showNotifications ? "show" : "hide"}`}>
        <div className="notification-header">
          <span>Thông Báo</span>
          <FaTimes className="close-btn" onClick={toggleNotifications} />
        </div>
        <div className="notification-content">
          {notifications.length > 0 ? (
            notifications.map((item) => (
              <div className="notification-item" key={item.id}>
                <span className="user-icon"></span>
                <div className="notification-text">
                  <strong>{item.name || item.context}</strong>
                  <p>{item.message || item.time}</p>
                </div>
                <FaEllipsisV className="notification-options" />
              </div>
            ))
          ) : (
            <div className="no-notifications">Không có thông báo</div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Testslist;