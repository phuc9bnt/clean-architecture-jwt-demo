import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  FaBook,
  FaBell,
  FaHeadset,
  FaCog,
  FaSignOutAlt,
  FaTimes,
  FaEllipsisV,
} from "react-icons/fa";
import { Link, useNavigate } from "react-router-dom";
import "./HomeScreenAdmin.css";

const HomeScreenAdmin = () => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [selectedGradeIndex, setSelectedGradeIndex] = useState(null);
  const [grades, setGrades] = useState([]);
  // Lưu data lớp học được lấy từ API Grade (giả sử mỗi object grade có thuộc tính "classes")
  const [classesData, setClassesData] = useState({});
  const [notifications, setNotifications] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem("accessToken");
    if (!token) {
      navigate("/login");
    } else {
      axios.defaults.headers.common["Authorization"] = `Bearer ${token}`;
      fetchGrades();
      fetchNotifications();
    }
  }, [navigate]);

  const logout = () => {
    localStorage.removeItem("accessToken");
    delete axios.defaults.headers.common["Authorization"];
    navigate("/login");
  };

  const toggleNotifications = () => {
    setShowNotifications((prev) => !prev);
  };

  // Lấy data Grade và extract luôn danh sách lớp học cho từng khối
  const fetchGrades = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await axios.get("http://localhost:5026/api/Grade");
      console.log("API Grade response:", response.data);
      if (response.data && Array.isArray(response.data)) {
        setGrades(response.data);
        // Giả sử mỗi grade có thuộc tính "classes" chứa mảng danh sách lớp
        const classesDataTemp = {};
        response.data.forEach((grade, index) => {
          classesDataTemp[index] = grade.classes || [];
        });
        setClassesData(classesDataTemp);
        localStorage.setItem("grades", JSON.stringify(response.data));
      } else {
        const cachedGrades = localStorage.getItem("grades");
        if (cachedGrades) {
          const parsedGrades = JSON.parse(cachedGrades);
          setGrades(parsedGrades);
          const classesDataTemp = {};
          parsedGrades.forEach((grade, index) => {
            classesDataTemp[index] = grade.classes || [];
          });
          setClassesData(classesDataTemp);
        } else {
          setError("Dữ liệu API hongg đúng định dạng");
        }
      }
    } catch (error) {
      console.error("Lỗi khi lấy dữ liệu khối lớp:", error);
      if (error.response && error.response.status === 401) {
        logout();
        return;
      }
      const cachedGrades = localStorage.getItem("grades");
      if (cachedGrades) {
        const parsedGrades = JSON.parse(cachedGrades);
        if (parsedGrades && parsedGrades.length > 0) {
          setGrades(parsedGrades);
          const classesDataTemp = {};
          parsedGrades.forEach((grade, index) => {
            classesDataTemp[index] = grade.classes || [];
          });
          setClassesData(classesDataTemp);
          console.log("Đã tải dữ liệu khối lớp từ localStorage");
        } else {
          setError("Hongg thể tải dữ liệu khối lớp. Vui lòng thử lại sau.");
        }
      } else {
        setError("Hongg thể tải dữ liệu khối lớp. Vui lòng thử lại sau.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const fetchNotifications = async () => {
    try {
      const response = await axios.get("http://localhost:5026/api/Notification");
      if (response.data) {
        setNotifications(response.data);
        localStorage.setItem("notifications", JSON.stringify(response.data));
      }
    } catch (error) {
      console.error("Lỗi khi lấy dữ liệu thông báo:", error);
      if (error.response && error.response.status === 401) {
        logout();
        return;
      }
      const cachedNotifications = localStorage.getItem("notifications");
      if (cachedNotifications) {
        setNotifications(JSON.parse(cachedNotifications));
      }
    }
  };

  // Bỏ call API riêng cho lớp học, chỉ cần toggle hiển thị dropdown thôi
  const handleBlockClick = (gradeIndex) => {
    if (selectedGradeIndex === gradeIndex) {
      setSelectedGradeIndex(null);
      return;
    }
    setSelectedGradeIndex(gradeIndex);
  };

  return (
    <div className="testslist-body">
      <div className="sidebar">
        <div className="logo">
          <img src="images/logo.jpg" alt="Logo" className="logo-image" />
        </div>
        <div className="settings-icon">
          <FaCog className="function-icon" />
        </div>
        <div className="function-icons">
          <Link to="/homeadmin" className="icon-item active">
            <FaBook className="function-icon" />
            <p className="icon-description">Môn học</p>
          </Link>
          <Link to="/support" className="icon-item">
            <FaHeadset className="function-icon" />
            <p className="icon-description">Hỗ trợ</p>
          </Link>
          <div className="icon-item" onClick={toggleNotifications}>
            <FaBell className="function-icon" />
            <p className="icon-description">Thông báo</p>
          </div>
          <div className="icon-item" onClick={logout}>
            <FaSignOutAlt className="function-icon" />
            <p className="icon-description">Đăng xuất</p>
          </div>
        </div>
      </div>

      <div className="main-content">
        <div className="headerad">
          <h1 className="title">Quản Lý Lớp Học</h1>
        </div>

        {isLoading && <div className="loading">Đang tải dữ liệu...</div>}
        {error && grades.length === 0 && <div className="error-message">{error}</div>}

        <div className="blocks-container">
          {grades.length > 0 ? (
            grades.map((grade, index) => (
              <div key={index} className="block-container">
                <div className="block" onClick={() => handleBlockClick(index)}>
                  <span>{grade.name}</span>
                  <div className={`arrow ${selectedGradeIndex === index ? "open" : ""}`}></div>
                </div>
                {selectedGradeIndex === index && (
                  <div className="table-container">
                    {classesData[index] && classesData[index].length > 0 ? (
                      <table>
                        <thead>
                          <tr>
                            <th>Lớp</th>
                            <th>Sĩ số</th>
                            <th>Năm học</th>
                          </tr>
                        </thead>
                        <tbody>
                          {classesData[index].map((classInfo, classIndex) => (
                            <tr key={classIndex}>
                              <td>{classInfo.name}</td>
                              <td>{classInfo.totalStudent}</td>
                              <td>
                                {typeof classInfo.year === "string"
                                  ? classInfo.year.trim()
                                  : classInfo.year}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    ) : (
                      <div className="no-data">
                        Hongg có lớp học hoặc đang tải...
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))
          ) : !isLoading && !error ? (
            <div className="no-data">Hongg có dữ liệu khối lớp</div>
          ) : null}
        </div>

        <div className={`notification-box ${showNotifications ? "show" : "hide"}`}>
          <div className="notification-header">
            <span>Thông Báo</span>
            <FaTimes className="close-btn" onClick={toggleNotifications} />
          </div>
          <div className="notification-content">
            {notifications.length > 0 ? (
              notifications.map((item) => (
                <div
                  className="notification-item"
                  key={item.id || Math.random()}
                >
                  <div className="notification-text">
                    <strong>{item.name || item.context}</strong>
                    <p>{item.message || item.time}</p>
                  </div>
                  <FaEllipsisV className="notification-options" />
                </div>
              ))
            ) : (
              <div className="no-notifications">Hongg có thông báo</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomeScreenAdmin;