import React, { useEffect, useState } from "react";
import axios from "axios";
import "./cc.css";
import {
  FaBook,
  FaBell,
  FaHeadset,
  FaCog,
  FaPlus,
  FaSignOutAlt,
  FaTimes,
  FaEllipsisV,
  FaChevronLeft,
  FaChevronRight,
} from "react-icons/fa";
import { Link } from "react-router-dom";

const Testslist = () => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [data, setData] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState([]);

  // Cố định 10 giáo viên mỗi trang  
  const pageSize = 10;

  const toggleNotifications = () => {
    setShowNotifications((prev) => !prev);
  };

  // Hàm xử lý hiển thị ngày tháng an toàn
  const formatDate = (dateStr) => {
    try {
      if (!dateStr) return '';
      // Kiểm tra nếu dateStr đã là định dạng ngày thẳng (dd/mm/yyyy)
      if (typeof dateStr === 'string' && dateStr.includes('/')) {
        return dateStr;
      }

      // Nếu là đối tượng Date hoặc string ISO, convert
      return new Date(dateStr).toLocaleDateString('vi-VN');
    } catch (error) {
      // Trả về giá trị gốc nếu không chuyển đổi được
      return dateStr || '';
    }
  };

  // Hàm lấy dữ liệu giáo viên với phân trang  
  const fetchTeachers = async (pageNumber = 1) => {
    setIsLoading(true);
    try {
      // Thay đổi URL tạm thời để test với dữ liệu students
      const response = await axios.get(`http://localhost:5026/Teacher/PageNumber?pageNumber=${pageNumber}&pageSize=${pageSize}`);
      // Truy cập mảng students từ phản hồi
      const responseData = response.data;
      console.log("Dữ liệu từ API:", responseData);

      // Map students data thành dạng teachers để hiển thị
      const teachers = (responseData.students || []).map(student => ({
        id: student.id,
        name: student.name,
        phone: student.phoneNumber,
        subjectID: student.subjectID,
        birthDate: student.birthDate,
        gender: student.gender === 'male' ? 'Nam' : 'Nữ',
        firstLogin: student.firstLogin,
        email: student.email,
        class: 'Chưa phân lớp' // Không có thông tin lớp trong dữ liệu students
      }));

      setData(teachers);

      // Tính toán tổng số trang từ totalCount và pageSize
      let calculatedTotalPages = 1;
      if (responseData.totalCount && responseData.totalCount > 0) {
        calculatedTotalPages = Math.ceil(responseData.totalCount / pageSize);
      }
      setTotalPages(calculatedTotalPages);
      setCurrentPage(responseData.pageNumber || 1);

      // Lưu dữ liệu vào localStorage để có thể tìm kiếm offline
      localStorage.setItem("teachers", JSON.stringify(teachers));
      localStorage.setItem("totalTeachers", responseData.totalCount);
    } catch (error) {
      console.error("Lỗi khi lấy dữ liệu giáo viên:", error);

      // Nếu không kết nối được với API, thử lấy dữ liệu từ localStorage
      const cachedTeachers = localStorage.getItem("teachers");
      if (cachedTeachers) {
        setData(JSON.parse(cachedTeachers));
        const totalCount = localStorage.getItem("totalTeachers") || 10;
        setTotalPages(Math.ceil(Number(totalCount) / pageSize));
        console.log("Đã tải dữ liệu từ localStorage");
      }
    } finally {
      setIsLoading(false);
    }
  };

  // Hàm tìm kiếm giáo viên sử dụng localStorage
  const searchTeachers = () => {
    if (!searchQuery.trim()) {
      setIsSearching(false);
      fetchTeachers(currentPage);
      return;
    }

    setIsLoading(true);
    setIsSearching(true);

    try {
      console.log("Đang tìm kiếm giáo viên với từ khóa:", searchQuery);

      // Tìm kiếm trong localStorage trước
      const cachedTeachers = localStorage.getItem("teachers");
      if (cachedTeachers) {
        const allTeachers = JSON.parse(cachedTeachers);
        const query = searchQuery.toLowerCase();

        // Tìm kiếm theo ID hoặc tên
        const filteredTeachers = allTeachers.filter(teacher =>
          (teacher.id && teacher.id.toString().toLowerCase().includes(query)) ||
          (teacher.name && teacher.name.toLowerCase().includes(query))
        );

        console.log("Kết quả tìm kiếm từ localStorage:", filteredTeachers);
        setSearchResults(filteredTeachers);

        // Nếu không tìm thấy trong localStorage, thử gọi API
        if (filteredTeachers.length === 0) {
          searchFromAPI();
        }
      } else {
        // Nếu không có dữ liệu trong localStorage, gọi API
        searchFromAPI();
      }
    } catch (error) {
      console.error("Lỗi khi tìm kiếm giáo viên:", error);
      setSearchResults([]);
    } finally {
      setIsLoading(false);
    }
  };

  // Hàm tìm kiếm thông qua API
  const searchFromAPI = async () => {
    try {
      // Sử dụng API endpoint của Student để test
      const url = `http://localhost:5026/Teacher/search?name=${encodeURIComponent(searchQuery)}&id=${encodeURIComponent(searchQuery)}`;
      console.log("Đang tìm kiếm từ API:", url);

      const response = await axios.get(url, {
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        }
      });

      console.log("Kết quả từ API:", response.data);

      if (response.data && Array.isArray(response.data)) {
        // Map students data thành dạng teachers để hiển thị
        const teachers = response.data.map(student => ({
          id: student.id,
          name: student.name,
          phone: student.phoneNumber,
          subjectID: student.subjectID,
          birthDate: student.birthDate,
          gender: student.gender === 'male' ? 'Nam' : 'Nữ',
          firstLogin: student.firstLogin,
          email: student.email,
          class: 'Chưa phân lớp' // Không có thông tin lớp
        }));
        setSearchResults(teachers);
      } else {
        setSearchResults([]);
      }
    } catch (error) {
      console.error("Lỗi khi gọi API tìm kiếm:", error);
      setSearchResults([]);
    }
  };

  // Hàm xóa tìm kiếm
  const clearSearch = () => {
    setSearchQuery("");
    setIsSearching(false);
    fetchTeachers(currentPage);
  };

  // Xử lý khi người dùng thay đổi trang  
  const handlePageChange = (pageNumber) => {
    if (pageNumber < 1 || pageNumber > totalPages) return;
    setCurrentPage(pageNumber);
    fetchTeachers(pageNumber);
  };

  // Lấy dữ liệu thông báo  
  const fetchNotifications = async () => {
    try {
      const response = await axios.get("http://localhost:5026/api/Notification");
      const notificationData = response.data;
      setNotifications(notificationData);
      localStorage.setItem("notifications", JSON.stringify(notificationData));
    } catch (error) {
      console.error("Lỗi khi lấy dữ liệu thông báo:", error);
      // Sử dụng dữ liệu từ localStorage nếu có
      const cachedNotifications = localStorage.getItem("notifications");
      if (cachedNotifications) {
        setNotifications(JSON.parse(cachedNotifications));
      }
    }
  };

  // Gọi API khi component mount  
  useEffect(() => {
    fetchTeachers(1); // Luôn bắt đầu với trang 1  
    fetchNotifications();
  }, []);

  // Hiển thị phân trang an toàn
  const renderPagination = () => {
    // Đảm bảo totalPages là một số hợp lệ
    const safeTotal = Math.max(1, totalPages || 1);

    // Nếu chỉ có 1 trang, không hiển thị phân trang
    if (safeTotal <= 1) {
      return null;
    }

    // Giới hạn số nút hiển thị để tránh quá nhiều
    const maxButtonsToShow = 5;
    let startPage = Math.max(1, currentPage - Math.floor(maxButtonsToShow / 2));
    let endPage = Math.min(safeTotal, startPage + maxButtonsToShow - 1);

    // Điều chỉnh lại nếu cần
    if (endPage - startPage + 1 < maxButtonsToShow) {
      startPage = Math.max(1, endPage - maxButtonsToShow + 1);
    }

    // Tạo mảng các số trang
    const pages = [];
    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }

    return (
      <div className="pagination">
        <button
          className="page-btn"
          disabled={currentPage === 1}
          onClick={() => handlePageChange(currentPage - 1)}
        >
          <FaChevronLeft />
        </button>

        {pages.map(pageNumber => (
          <button
            key={pageNumber}
            className={`page-btn ${currentPage === pageNumber ? "active" : ""}`}
            onClick={() => handlePageChange(pageNumber)}
          >
            {pageNumber}
          </button>
        ))}

        {endPage < safeTotal && (
          <>
            <span className="dots">...</span>
            <button
              className="page-btn"
              onClick={() => handlePageChange(safeTotal)}
            >
              {safeTotal}
            </button>
          </>
        )}

        <button
          className="page-btn"
          disabled={currentPage === safeTotal}
          onClick={() => handlePageChange(currentPage + 1)}
        >
          <FaChevronRight />
        </button>
      </div>
    );
  };

  return (
    <div className="testslist-body">
      {/* Sidebar */}
      <div className="sidebar">
        <div className="logo">
          <img src="images/logo.jpg" alt="Logo" className="logo-image" />
        </div>
        <div className="settings-icon">
          <FaCog className="function-icon" />
        </div>
        <div className="function-icons">
          <Link to="/addnewtest1" className="icon-item active">
            <FaBook className="function-icon" />
            <p className="icon-description">Môn học</p>
          </Link>
          <Link to="/support" className="icon-item">
            <FaHeadset className="function-icon" />
            <p className="icon-description">Hỗ trợ</p>
          </Link>
          <div className="icon-item" onClick={toggleNotifications}>
            <FaBell className="function-icon" />
            <p className="icon-description">Thông báo</p>
          </div>
          <Link to="/logout" className="icon-item">
            <FaSignOutAlt className="function-icon" />
            <p className="icon-description">Đăng xuất</p>
          </Link>
        </div>
      </div>

      {/* Main Content */}
      <div className="main-content">
        {/* Header */}
        <div className="header">
          <h1 className="title">Teacher List</h1>
          <div className="search-wrapper">
            <input
              type="text"
              className="search-input"
              placeholder="Tìm kiếm giáo viên theo ID hoặc tên..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && searchTeachers()}
            />
            <FaCog
              className="search-icon"
              onClick={searchTeachers}
            />
            {isSearching && (
              <FaTimes
                className="clear-search-icon"
                onClick={clearSearch}
              />
            )}
          </div>
          <Link to="/addteacher" className="add-btn">
            <FaPlus />
          </Link>
        </div>

        {/* Table */}
        {isLoading ? (
          <div className="loading">Đang tải dữ liệu...</div>
        ) : (
          <div className="table-container">
            <table className="table-kho-de">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Họ và Tên</th>
                  <th>SĐT</th>
                  <th>Môn học</th>
                  <th>Ngày Sinh</th>
                  <th>Giới Tính</th>
                  <th>Đăng nhập lần đầu</th>
                  <th>Email</th>
                </tr>
              </thead>
              <tbody>
                {isSearching ? (
                  searchResults.length > 0 ? (
                    searchResults.map((row, index) => (
                      <tr key={index}>
                        <td>{row.id}</td>
                        <td>{row.name}</td>
                        <td>{row.phone}</td>
                        <td>{row.subjectID}</td>
                        <td>{formatDate(row.birthDate)}</td>
                        <td>{row.gender}</td>
                        <td>{formatDate(row.firstLogin)}</td>
                        <td>{row.email}</td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="8" style={{ textAlign: "center" }}>
                        Không tìm thấy kết quả phù hợp với từ khóa: "{searchQuery}"
                      </td>
                    </tr>
                  )
                ) : (
                  data && data.length > 0 ? (
                    data.map((row, index) => (
                      <tr key={index}>
                        <td>{row.id}</td>
                        <td>{row.name}</td>
                        <td>{row.phone}</td>
                        <td>{row.subjectID}</td>
                        <td>{formatDate(row.birthDate)}</td>
                        <td>{row.gender}</td>
                        <td>{formatDate(row.firstLogin)}</td>
                        <td>{row.email}</td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="8" style={{ textAlign: "center" }}>Không có dữ liệu</td>
                    </tr>
                  )
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination - chỉ hiển thị khi không tìm kiếm */}
        {!isSearching && renderPagination()}

        {/* Hiển thị thông tin trang - điều chỉnh dựa trên trạng thái tìm kiếm */}
        <div className={isSearching ? "search-results-info" : "pagination-info"}>
          {isSearching ? (
            `Kết quả tìm kiếm: ${searchResults.length} giáo viên`
          ) : (
            `Trang ${currentPage} / ${totalPages > 0 ? totalPages : 1} | Tổng số: ${data.length} giáo viên`
          )}
        </div>
      </div>

      {/* Notifications */}
      <div className={`notification-box ${showNotifications ? "show" : "hide"}`}>
        <div className="notification-header">
          <span>Thông Báo</span>
          <FaTimes className="close-btn" onClick={toggleNotifications} />
        </div>
        <div className="notification-content">
          {notifications.length > 0 ? (
            notifications.map((item) => (
              <div className="notification-item" key={item.id}>
                <span className="user-icon"></span>
                <div className="notification-text">
                  <strong>{item.name || item.context}</strong>
                  <p>{item.message || item.time}</p>
                </div>
                <FaEllipsisV className="notification-options" />
              </div>
            ))
          ) : (
            <div className="no-notifications">Không có thông báo</div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Testslist;