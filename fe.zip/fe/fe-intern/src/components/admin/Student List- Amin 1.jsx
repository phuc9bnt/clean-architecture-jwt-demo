import React, { useEffect, useState } from "react";  
import axios from "axios";  
import "./cc.css";  
import {  
  FaBook,  
  FaBell,  
  FaHeadset,  
  FaCog,  
  FaPlus,  
  FaSignOutAlt,  
  FaTimes,  
  FaEllipsisV,  
  FaChevronLeft,  
  FaChevronRight,
} from "react-icons/fa";  
import { Link } from "react-router-dom";  

const Testslist = () => {  
  const [showNotifications, setShowNotifications] = useState(false);  
  const [data, setData] = useState([]);  
  const [notifications, setNotifications] = useState([]);  
  const [currentPage, setCurrentPage] = useState(1);  
  const [totalPages, setTotalPages] = useState(1);  
  const [isLoading, setIsLoading] = useState(false);  
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState([]);
  
  // Cố định 10 sinh viên mỗi trang  
  const pageSize = 10;  

  const toggleNotifications = () => {  
    setShowNotifications((prev) => !prev);  
  };  

  // Hàm lấy dữ liệu sinh viên với phân trang  
  const fetchStudents = async (pageNumber = 1) => {  
    setIsLoading(true);  
    try {  
      const response = await axios.get(`http://localhost:5026/Student/PageNumber?pageNumber=${pageNumber}&pageSize=${pageSize}`);  
      // Truy cập mảng students từ phản hồi
      const responseData = response.data;
      setData(responseData.students || []);  
      // Tính toán tổng số trang từ totalCount và pageSize
      const calculatedTotalPages = Math.ceil(responseData.totalCount / pageSize);
      setTotalPages(calculatedTotalPages || 1);  
      setCurrentPage(responseData.pageNumber || 1);
      
      // Lưu dữ liệu vào localStorage để có thể tìm kiếm offline
      localStorage.setItem("students", JSON.stringify(responseData.students || []));
      localStorage.setItem("totalStudents", responseData.totalCount);
    } catch (error) {  
      console.error("Lỗi khi lấy dữ liệu sinh viên:", error);  
      
      // Nếu không kết nối được với API, thử lấy dữ liệu từ localStorage
      const cachedStudents = localStorage.getItem("students");
      if (cachedStudents) {
        setData(JSON.parse(cachedStudents));
        const totalCount = localStorage.getItem("totalStudents") || 10;
        setTotalPages(Math.ceil(totalCount / pageSize));
        console.log("Đã tải dữ liệu từ localStorage");
      }
    } finally {  
      setIsLoading(false);  
    }  
  };  

  // Hàm tìm kiếm học sinh sử dụng localStorage
  const searchStudents = () => {
    if (!searchQuery.trim()) {
      setIsSearching(false);
      fetchStudents(currentPage);
      return;
    }
    
    setIsLoading(true);
    setIsSearching(true);
    
    try {
      console.log("Đang tìm kiếm sinh viên với từ khóa:", searchQuery);
      
      // Tìm kiếm trong localStorage trước
      const cachedStudents = localStorage.getItem("students");
      if (cachedStudents) {
        const allStudents = JSON.parse(cachedStudents);
        const query = searchQuery.toLowerCase();
        
        // Tìm kiếm theo ID hoặc tên
        const filteredStudents = allStudents.filter(student => 
          (student.id && student.id.toLowerCase().includes(query)) || 
          (student.name && student.name.toLowerCase().includes(query))
        );
        
        console.log("Kết quả tìm kiếm từ localStorage:", filteredStudents);
        setSearchResults(filteredStudents);
        
        // Nếu không tìm thấy trong localStorage, thử gọi API
        if (filteredStudents.length === 0) {
          searchFromAPI();
        }
      } else {
        // Nếu không có dữ liệu trong localStorage, gọi API
        searchFromAPI();
      }
    } catch (error) {
      console.error("Lỗi khi tìm kiếm học sinh:", error);
      setSearchResults([]);
    } finally {
      setIsLoading(false);
    }
  };
  
  // Hàm tìm kiếm thông qua API
  const searchFromAPI = async () => {
    try {
      const url = `http://localhost:5026/Student/search?name=${encodeURIComponent(searchQuery)}&id=${encodeURIComponent(searchQuery)}`;
      console.log("Đang tìm kiếm từ API:", url);
      
      const response = await axios.get(url, {
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        }
      });
      
      console.log("Kết quả từ API:", response.data);
      
      if (response.data && Array.isArray(response.data)) {
        setSearchResults(response.data);
      } else {
        setSearchResults([]);
      }
    } catch (error) {
      console.error("Lỗi khi gọi API tìm kiếm:", error);
      setSearchResults([]);
    }
  };

  // Hàm xóa tìm kiếm
  const clearSearch = () => {
    setSearchQuery("");
    setIsSearching(false);
    fetchStudents(currentPage);
  };

  // Xử lý khi người dùng thay đổi trang  
  const handlePageChange = (pageNumber) => {  
    if (pageNumber < 1 || pageNumber > totalPages) return;  
    setCurrentPage(pageNumber);  
    fetchStudents(pageNumber);  
  };  

  // Lấy dữ liệu thông báo  
  const fetchNotifications = async () => {  
    try {  
      const response = await axios.get("http://localhost:5026/api/Notification");  
      const notificationData = response.data;  
      setNotifications(notificationData);  
      localStorage.setItem("notifications", JSON.stringify(notificationData));  
    } catch (error) {  
      console.error("Lỗi khi lấy dữ liệu thông báo:", error);  
      
      // Nếu không kết nối được, thử lấy từ localStorage
      const cachedNotifications = localStorage.getItem("notifications");
      if (cachedNotifications) {
        setNotifications(JSON.parse(cachedNotifications));
      }
    }  
  };  

  // Gọi API khi component mount  
  useEffect(() => {  
    fetchStudents(1); // Luôn bắt đầu với trang 1  
    fetchNotifications();  
  }, []);  

  return (  
    <div className="testslist-body">  
      {/* Sidebar */}  
      <div className="sidebar">  
        <div className="logo">  
          <img src="images/logo.jpg" alt="Logo" className="logo-image" />  
        </div>  
        <div className="settings-icon">  
          <FaCog className="function-icon" />  
        </div>  
        <div className="function-icons">  
          <Link to="/addnewtest1" className="icon-item active">  
            <FaBook className="function-icon" />  
            <p className="icon-description">Môn học</p>  
          </Link>  
          <Link to="/support" className="icon-item">  
            <FaHeadset className="function-icon" />  
            <p className="icon-description">Hỗ trợ</p>  
          </Link>  
          <div className="icon-item" onClick={toggleNotifications}>  
            <FaBell className="function-icon" />  
            <p className="icon-description">Thông báo</p>  
          </div>  
          <Link to="/logout" className="icon-item">  
            <FaSignOutAlt className="function-icon" />  
            <p className="icon-description">Đăng xuất</p>  
          </Link>  
        </div>  
      </div>  

      {/* Main Content */}  
      <div className="main-content">  
        {/* Header */}  
        <div className="header">  
          <h1 className="title">Student List</h1>  
          <div className="search-wrapper">  
            <input 
              type="text" 
              className="search-input" 
              placeholder="Tìm kiếm học sinh theo ID hoặc tên..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && searchStudents()}
            />
            <FaCog 
              className="search-icon" 
              onClick={searchStudents}
            />
            {isSearching && (
              <FaTimes
                className="clear-search-icon"
                onClick={clearSearch}
              />
            )}
          </div>  
          <Link to="/addstudent" className="add-btn">  
            <FaPlus />  
          </Link>  
        </div>  

        {/* Table */}  
        {isLoading ? (  
          <div className="loading">Đang tải dữ liệu...</div>  
        ) : (  
          <div className="table-container">  
            <table className="table-kho-de">  
              <thead>  
                <tr>  
                  <th>ID</th>  
                  <th>Họ và Tên</th>  
                  <th>Giới Tính</th>  
                  <th>Email</th>  
                  <th>SĐT Phụ Huynh</th>  
                  <th>Ngày Sinh</th>  
                  <th>Hình Ảnh</th>  
                  <th>Đăng Nhập Đầu Tiên</th>  
                  <th>Môn Học</th>  
                  <th>Mã Học Sinh</th>  
                </tr>  
              </thead>  
              <tbody>
                {isSearching ? (
                  searchResults.length > 0 ? (
                    searchResults.map((row, index) => (
                      <tr key={index}>
                        <td>{row.id}</td>
                        <td>{row.name}</td>
                        <td>{row.gender}</td>
                        <td>{row.mail}</td>
                        <td>{row.phoneNumber}</td>
                        <td>{new Date(row.birthDate).toLocaleDateString('vi-VN')}</td>
                        <td>
                          {row.image && <img src={row.image} alt={row.name} className="student-image" />}
                        </td>
                        <td>{new Date(row.firstLogin).toLocaleDateString('vi-VN')}</td>
                        <td>{row.subject}</td>
                        <td>{row.studentCode}</td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="10" style={{textAlign: "center"}}>
                        Không tìm thấy kết quả phù hợp với từ khóa: "{searchQuery}"
                      </td>
                    </tr>
                  )
                ) : (
                  data && data.length > 0 ? (  
                    data.map((row, index) => (  
                      <tr key={index}>  
                        <td>{row.id}</td>  
                        <td>{row.name}</td>  
                        <td>{row.gender}</td>  
                        <td>{row.mail}</td>  
                        <td>{row.phoneNumber}</td>  
                        <td>{new Date(row.birthDate).toLocaleDateString('vi-VN')}</td>  
                        <td>  
                          {row.image && <img src={row.image} alt={row.name} className="student-image" />}  
                        </td>  
                        <td>{new Date(row.firstLogin).toLocaleDateString('vi-VN')}</td>  
                        <td>{row.subject}</td>  
                        <td>{row.studentCode}</td>  
                      </tr>  
                    ))  
                  ) : (  
                    <tr>  
                      <td colSpan="10" style={{textAlign: "center"}}>Không có dữ liệu</td>  
                    </tr>  
                  )
                )}
              </tbody>
            </table>  
          </div>  
        )}

        {/* Pagination - chỉ hiển thị khi không tìm kiếm */}
        {!isSearching && (
          <div className="pagination">  
            <button   
              className="page-btn"   
              disabled={currentPage === 1}  
              onClick={() => handlePageChange(currentPage - 1)}  
            >  
              <FaChevronLeft />  
            </button>  
            
            {[...Array(totalPages)].map((_, index) => {  
              const pageNumber = index + 1;  
              return (  
                <button   
                  key={pageNumber}   
                  className={`page-btn ${currentPage === pageNumber ? "active" : ""}`}  
                  onClick={() => handlePageChange(pageNumber)}  
                >  
                  {pageNumber}  
                </button>  
              );  
            })}  
            
            <button   
              className="page-btn"   
              disabled={currentPage === totalPages}  
              onClick={() => handlePageChange(currentPage + 1)}  
            >  
              <FaChevronRight />  
            </button>  
          </div>
        )}

        {/* Hiển thị thông tin trang - điều chỉnh dựa trên trạng thái tìm kiếm */}
        <div className={isSearching ? "search-results-info" : "pagination-info"}>
          {isSearching ? (
            `Kết quả tìm kiếm: ${searchResults.length} học sinh`
          ) : (
            `Trang ${currentPage} / ${totalPages} | Tổng số: ${data.length} học sinh`
          )}
        </div>
      </div>  

      {/* Notifications */}  
      <div className={`notification-box ${showNotifications ? "show" : "hide"}`}>  
        <div className="notification-header">  
          <span>Thông Báo</span>  
          <FaTimes className="close-btn" onClick={toggleNotifications} />  
        </div>  
        <div className="notification-content">  
          {notifications.length > 0 ? (  
            notifications.map((item) => (  
              <div className="notification-item" key={item.id}>  
                <span className="user-icon"></span>  
                <div className="notification-text">  
                  <strong>{item.context}</strong>  
                  <p>{item.time}</p>  
                </div>  
                <FaEllipsisV className="notification-options" />  
              </div>  
            ))  
          ) : (  
            <div className="no-notifications">Không có thông báo</div>  
          )}  
        </div>  
      </div>  
    </div>  
  );  
};  

/*.*/

export default Testslist;
