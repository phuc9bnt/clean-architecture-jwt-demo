import React, { useState, useEffect } from "react";
import axios from "axios";
import "./cc.css";
import { FaBook, FaBell, FaHeadset, FaCog, FaSignOutAlt, FaTimes, FaEllipsisV, FaChevronLeft, FaChevronRight } from "react-icons/fa";
import { Link } from "react-router-dom";
 
const Testslist = () => {
    const [showNotifications, setShowNotifications] = useState(false);
    const [notifications, setNotifications] = useState([]);
    const [students, setStudents] = useState([]);
    const [teachers, setTeachers] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [currentStudentPage, setCurrentStudentPage] = useState(1);
    const [currentTeacherPage, setCurrentTeacherPage] = useState(1);
    const [totalStudentPages, setTotalStudentPages] = useState(1);
    const [totalTeacherPages, setTotalTeacherPages] = useState(1);
    
    // Cố định số lượng mỗi trang
    const pageSize = 3;
 
    const toggleNotifications = () => {
        setShowNotifications(prev => !prev);
    };
 
    // Hàm lấy dữ liệu học sinh với phân trang
    const fetchStudents = async (pageNumber = 1) => {
        setIsLoading(true);
        try {
            const response = await axios.get(`http://localhost:5026/Student/PageNumber?pageNumber=${pageNumber}&pageSize=${pageSize}`);
            const responseData = response.data;
            setStudents(responseData.students || []);
            
            // Tính toán tổng số trang từ totalCount và pageSize
            const calculatedTotalPages = Math.ceil(responseData.totalCount / pageSize);
            setTotalStudentPages(calculatedTotalPages || 1);
            setCurrentStudentPage(responseData.pageNumber || 1);
            
            // Lưu dữ liệu vào localStorage để có thể tìm kiếm offline
            localStorage.setItem("students", JSON.stringify(responseData.students || []));
            localStorage.setItem("totalStudents", responseData.totalCount);
        } catch (error) {
            console.error("Lỗi khi lấy dữ liệu học sinh:", error);
            
            // Nếu không kết nối được với API, thử lấy dữ liệu từ localStorage
            const cachedStudents = localStorage.getItem("students");
            if (cachedStudents) {
                setStudents(JSON.parse(cachedStudents));
                const totalCount = localStorage.getItem("totalStudents") || 10;
                setTotalStudentPages(Math.ceil(totalCount / pageSize));
                console.log("Đã tải dữ liệu học sinh từ localStorage");
            }
        } finally {
            setIsLoading(false);
        }
    };
 
    // Lấy dữ liệu giáo viên với phân trang
    const fetchTeachers = async (pageNumber = 1) => {
        setIsLoading(true);
        try {
            const response = await axios.get(`http://localhost:5026/Teacher/PageNumber?pageNumber=${pageNumber}&pageSize=${pageSize}`);
            const responseData = response.data;
            
            // Dữ liệu đã được chuẩn hóa theo đầu ra của API
            const teachers = (responseData.students || []).map(teacher => ({
                id: teacher.id,
                name: teacher.name,
                gender: teacher.gender === 'Female' ? 'Nữ' : 'Nam',
                email: teacher.mail,
                phone: teacher.phoneNumber,
                subjectID: teacher.subjectID,
                birthDate: teacher.birthDate,
                image: teacher.image
            }));
            
            setTeachers(teachers);
            
            // Tính toán tổng số trang từ totalCount và pageSize
            const calculatedTotalPages = Math.ceil(responseData.totalCount / pageSize);
            setTotalTeacherPages(calculatedTotalPages || 1);
            setCurrentTeacherPage(responseData.pageNumber || 1);
            
            // Lưu dữ liệu vào localStorage để có thể tìm kiếm offline
            localStorage.setItem("teachers", JSON.stringify(teachers));
            localStorage.setItem("totalTeachers", responseData.totalCount);
        } catch (error) {
            console.error("Lỗi khi lấy dữ liệu giáo viên:", error);
            
            // Nếu không kết nối được với API, thử lấy dữ liệu từ localStorage
            const cachedTeachers = localStorage.getItem("teachers");
            if (cachedTeachers) {
                setTeachers(JSON.parse(cachedTeachers));
                const totalCount = localStorage.getItem("totalTeachers") || 10;
                setTotalTeacherPages(Math.ceil(Number(totalCount) / pageSize));
                console.log("Đã tải dữ liệu giáo viên từ localStorage");
            }
        } finally {
            setIsLoading(false);
        }
    };
 
    // Lấy dữ liệu thông báo
    const fetchNotifications = async () => {
        try {
            const response = await axios.get("http://localhost:5026/api/Notification");
            const notificationData = response.data;
            setNotifications(notificationData);
            localStorage.setItem("notifications", JSON.stringify(notificationData));
        } catch (error) {
            console.error("Lỗi khi lấy dữ liệu thông báo:", error);
            // Sử dụng dữ liệu từ localStorage nếu có
            const cachedNotifications = localStorage.getItem("notifications");
            if (cachedNotifications) {
                setNotifications(JSON.parse(cachedNotifications));
            }
        }
    };
 
    // Xử lý khi người dùng thay đổi trang học sinh
    const handleStudentPageChange = (pageNumber) => {
        if (pageNumber < 1 || pageNumber > totalStudentPages) return;
        setCurrentStudentPage(pageNumber);
        fetchStudents(pageNumber);
    };
 
    // Xử lý khi người dùng thay đổi trang giáo viên
    const handleTeacherPageChange = (pageNumber) => {
        if (pageNumber < 1 || pageNumber > totalTeacherPages) return;
        setCurrentTeacherPage(pageNumber);
        fetchTeachers(pageNumber);
    };
    
    // Hàm format ngày tháng dạng dd/mm/yyyy
    const formatDate = (dateString) => {
        if (!dateString) return '';
        
        try {
            const date = new Date(dateString);
            return date.toLocaleDateString('vi-VN', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric'
            }).replace(/\//g, '/');
        } catch (error) {
            return dateString;
        }
    };
    
    // Tạo mảng số trang cho phân trang
    const getPageNumbers = (currentPage, totalPages) => {
        // Nếu tổng số trang <= 5, hiển thị tất cả các trang
        if (totalPages <= 5) {
            return Array.from({ length: totalPages }, (_, i) => i + 1);
        }
        
        // Nếu đang ở gần đầu, hiển thị 5 trang đầu
        if (currentPage <= 3) {
            return [1, 2, 3, 4, 5];
        }
        
        // Nếu đang ở gần cuối, hiển thị 5 trang cuối
        if (currentPage >= totalPages - 2) {
            return Array.from({ length: 5 }, (_, i) => totalPages - 4 + i);
        }
        
        // Nếu ở giữa, hiển thị trang hiện tại và 2 trang trước, 2 trang sau
        return [currentPage - 2, currentPage - 1, currentPage, currentPage + 1, currentPage + 2];
    };
    
    // Gọi API khi component mount
    useEffect(() => {
        fetchStudents(1);
        fetchTeachers(1);
        fetchNotifications();
    }, []);
    
    return (
        <div className="testslist-body">
            <div className="sidebar">
                <div className="logo">
                    <img src="images/logo.jpg" alt="Logo" className="logo-image" />
                </div>
                <div className="settings-icon">
                    <FaCog className="function-icon" />
                </div>
                <div className="function-icons">
                    <Link to="/addnewtest1" className="icon-item active">
                        <FaBook className="function-icon" />
                        <p className="icon-description">Môn học</p>
                    </Link>
                    <Link to="/support" className="icon-item">
                        <FaHeadset className="function-icon" />
                        <p className="icon-description">Hỗ trợ</p>
                    </Link>
                    <div className="icon-item" onClick={toggleNotifications}>
                        <FaBell className="function-icon" />
                        <p className="icon-description">Thông báo</p>
                    </div>
                    <Link to="/logout" className="icon-item">
                        <FaSignOutAlt className="function-icon" />
                        <p className="icon-description">Đăng xuất</p>
                    </Link>
                </div>
            </div>
 
            <div className="main-content">
                <div className="header">
                    <h1 className="title">4A1</h1>
                </div>
 
                {isLoading ? (
                    <div className="loading">Đang tải dữ liệu...</div>
                ) : (
                    <>
                        {/* Học Sinh Table */}
                        <div className="table-container">
                            <h2>Học Sinh</h2>
                            <table className="table-kho-de">
                                <thead>
                                    <tr>
                                       
                                        <th>Họ Và Tên</th>
                                        <th>Giới Tính</th>
                                        <th>Email</th>
                                        <th>SĐT Phụ Huynh</th>
                                        <th>Ngày Sinh</th>
                                        <th>Ảnh</th>
                                        <th>Mã Học Sinh</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {students.length > 0 ? (
                                        students.map((student, index) => (
                                            <tr key={index}>
                                              
                                                <td>{student.name}</td>
                                                <td>{student.gender === 'Female' ? 'Nữ' : 'Nam'}</td>
                                                <td>{student.mail}</td>
                                                <td>{student.phoneNumber}</td>
                                                <td>{formatDate(student.birthDate)}</td>
                                                <td>
                                                    {student.image ? (
                                                        <img 
                                                            src={`http://localhost:5026/images/${student.image}`} 
                                                            alt="" 
                                                            className="student-image" 
                                                        />
                                                    ) : null}
                                                </td>
                                                <td>{student.studentCode}</td>
                                            </tr>
                                        ))
                                    ) : (
                                        <tr>
                                            <td colSpan="8" style={{textAlign: "center"}}>Không có dữ liệu học sinh</td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                            
                            {/* Phân trang cho học sinh */}
                            <div className="student-pagination-container">
                                <div className="pagination">
                                    {/* Nút quay lại trang trước */}
                                    <button 
                                        className="page-btn" 
                                        disabled={currentStudentPage === 1}
                                        onClick={() => handleStudentPageChange(currentStudentPage - 1)}
                                    >
                                        <FaChevronLeft />
                                    </button>
                                    
                                    {/* Nút trang đầu tiên nếu không hiển thị trong danh sách */}
                                    {currentStudentPage > 3 && totalStudentPages > 5 && (
                                        <>
                                            <button
                                                className="page-btn"
                                                onClick={() => handleStudentPageChange(1)}
                                            >
                                                1
                                            </button>
                                            <span className="dots">...</span>
                                        </>
                                    )}
                                    
                                    {/* Các nút số trang */}
                                    {getPageNumbers(currentStudentPage, totalStudentPages).map(pageNumber => (
                                        <button
                                            key={pageNumber}
                                            className={`page-btn ${currentStudentPage === pageNumber ? "active" : ""}`}
                                            onClick={() => handleStudentPageChange(pageNumber)}
                                        >
                                            {pageNumber}
                                        </button>
                                    ))}
                                    
                                    {/* Hiển thị ... và nút trang cuối nếu cần */}
                                    {currentStudentPage < totalStudentPages - 2 && totalStudentPages > 5 && (
                                        <>
                                            <span className="dots">...</span>
                                            <button 
                                                className="page-btn"
                                                onClick={() => handleStudentPageChange(totalStudentPages)}
                                            >
                                                {totalStudentPages}
                                            </button>
                                        </>
                                    )}
                                    
                                    {/* Nút chuyển trang tiếp theo */}
                                    <button 
                                        className="page-btn" 
                                        disabled={currentStudentPage === totalStudentPages}
                                        onClick={() => handleStudentPageChange(currentStudentPage + 1)}
                                    >
                                        <FaChevronRight />
                                    </button>
                                </div>
                            </div>
                        </div>

                        {/* Giáo Viên Table */}
                        <div className="table-container" style={{marginTop: "40px"}}>
                            <h2>Giáo Viên</h2>
                            <table className="table-kho-de">
                                <thead>
                                    <tr>
                                        
                                        <th>Họ Và Tên</th>
                                        <th>Giới Tính</th>
                                        <th>Email</th>
                                        <th>SĐT</th>
                                        <th>Môn</th>
                                        <th>Ngày Sinh</th>
                                        <th>Ảnh</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {teachers.length > 0 ? (
                                        teachers.map((teacher, index) => (
                                            <tr key={index}>
                                               
                                                <td>{teacher.name}</td>
                                                <td>{teacher.gender}</td>
                                                <td>{teacher.email}</td>
                                                <td>{teacher.phone}</td>
                                                <td>{teacher.subjectID}</td>
                                                <td>{formatDate(teacher.birthDate)}</td>
                                                <td>
                                                    {teacher.image ? (
                                                        <img 
                                                            src={`http://localhost:5026/images/${teacher.image}`} 
                                                            alt="" 
                                                            className="teacher-image" 
                                                        />
                                                    ) : null}
                                                </td>
                                            </tr>
                                        ))
                                    ) : (
                                        <tr>
                                            <td colSpan="8" style={{textAlign: "center"}}>Không có dữ liệu giáo viên</td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                            
                            {/* Phân trang cho giáo viên */}
                            <div className="teacher-pagination-container">
                                <div className="pagination">
                                    {/* Nút quay lại trang trước */}
                                    <button 
                                        className="page-btn" 
                                        disabled={currentTeacherPage === 1}
                                        onClick={() => handleTeacherPageChange(currentTeacherPage - 1)}
                                    >
                                        <FaChevronLeft />
                                    </button>
                                    
                                    {/* Nút trang đầu tiên nếu không hiển thị trong danh sách */}
                                    {currentTeacherPage > 3 && totalTeacherPages > 5 && (
                                        <>
                                            <button
                                                className="page-btn"
                                                onClick={() => handleTeacherPageChange(1)}
                                            >
                                                1
                                            </button>
                                            <span className="dots">...</span>
                                        </>
                                    )}
                                    
                                    {/* Các nút số trang */}
                                    {getPageNumbers(currentTeacherPage, totalTeacherPages).map(pageNumber => (
                                        <button
                                            key={pageNumber}
                                            className={`page-btn ${currentTeacherPage === pageNumber ? "active" : ""}`}
                                            onClick={() => handleTeacherPageChange(pageNumber)}
                                        >
                                            {pageNumber}
                                        </button>
                                    ))}
                                    
                                    {/* Hiển thị ... và nút trang cuối nếu cần */}
                                    {currentTeacherPage < totalTeacherPages - 2 && totalTeacherPages > 5 && (
                                        <>
                                            <span className="dots">...</span>
                                            <button 
                                                className="page-btn"
                                                onClick={() => handleTeacherPageChange(totalTeacherPages)}
                                            >
                                                {totalTeacherPages}
                                            </button>
                                        </>
                                    )}
                                    
                                    {/* Nút chuyển trang tiếp theo */}
                                    <button 
                                        className="page-btn" 
                                        disabled={currentTeacherPage === totalTeacherPages}
                                        onClick={() => handleTeacherPageChange(currentTeacherPage + 1)}
                                    >
                                        <FaChevronRight />
                                    </button>
                                </div>
                            </div>
                        </div>
                    </>
                )}
            </div>

            <div className={`notification-box ${showNotifications ? "show" : "hide"}`}>
                <div className="notification-header">
                    <span>Thông Báo</span>
                    <FaTimes className="close-btn" onClick={toggleNotifications} />
                </div>
                <div className="notification-content">
                    {notifications.length > 0 ? (
                        notifications.map((item) => (
                            <div className="notification-item" key={item.id}>
                                <span className="user-icon"></span>
                                <div className="notification-text">
                                    <strong>{item.name || item.context}</strong>
                                    <p>{item.message || item.time}</p>
                                </div>
                                <FaEllipsisV className="notification-options" />
                            </div>
                        ))
                    ) : (
                        <div className="no-notifications">Không có thông báo</div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Testslist;