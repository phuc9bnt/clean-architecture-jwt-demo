import React, { useState } from "react";
import "./Onclass-SubjectScreen.css"; // 
import { FaBook, FaBell, FaHeadset, FaCog, FaSignOutAlt, FaTimes, FaEllipsisV } from "react-icons/fa"; // Các biểu tượng sử dụng trong sidebar
import { Link } from "react-router-dom"; // Dùng để chuyển trang trong ứng dụng React

const TestsList = () => {
const [showNotifications, setShowNotifications] = useState(false); // Quản lý trạng thái hiển thị thông báo
const [sortOrder, setSortOrder] = useState("asc"); // Quản lý thứ tự sắp xếp (mặc định là tăng dần)
const [searchQuery, setSearchQuery] = useState(""); // Quản lý giá trị tìm kiếm trong ô nhập liệu


// Dữ liệu thông báo
const notifications = [
{ id: 1, name: "Lê Thị Mỹ A", message: "" },
{ id: 2, name: "Nguyễn Văn Xương", message: "đã trả lời ticket của bạn" },
];

// Hàm thay đổi trạng thái hiển thị thông báo
const toggleNotifications = () => {
setShowNotifications((prev) => !prev);
};

// Dữ liệu các bài tập
const data = [
{ title: "Kiểm tra 15 phút - Đợt 1", testDate: "2025-04-01", test15p: 8, homework5: 9, homework4: 10, homework3: 7, homework2: 6, homework1: 8 },
{ title: "Bài tập về nhà buổi 1", testDate: "2023-04-05", test15p: 7, homework5: 8, homework4: 9, homework3: 6, homework2: 7, homework1: 9 },
{ title: "Bài tập về nhà buổi 2", testDate: "2023-03-28", test15p: 9, homework5: 9, homework4: 8, homework3: 8, homework2: 7, homework1: 10 },
{ title: "Kiểm tra 30 phút - Đợt 2", testDate: "2025-05-15", test15p: 8, homework5: 9, homework4: 10, homework3: 7, homework2: 6, homework1: 8 },
{ title: "Bài tập về nhà buổi 3", testDate: "2023-04-10", test15p: 7, homework5: 8, homework4: 9, homework3: 6, homework2: 7, homework1: 9 },
{ title: "Bài tập về nhà buổi 4", testDate: "2023-05-01", test15p: 9, homework5: 9, homework4: 8, homework3: 8, homework2: 7, homework1: 10 },
{ title: "Kiểm tra 15 phút - Đợt 3", testDate: "2025-06-05", test15p: 8, homework5: 9, homework4: 10, homework3: 7, homework2: 6, homework1: 8 },
{ title: "Bài tập về nhà buổi 5", testDate: "2023-04-15", test15p: 7, homework5: 8, homework4: 9, homework3: 6, homework2: 7, homework1: 9 },
{ title: "Bài tập về nhà buổi 6", testDate: "2023-05-10", test15p: 9, homework5: 9, homework4: 8, homework3: 8, homework2: 7, homework1: 10 },
{ title: "Kiểm tra 15 phút - Đợt 4", testDate: "2025-07-01", test15p: 8, homework5: 9, homework4: 10, homework3: 7, homework2: 6, homework1: 8 },
{ title: "Bài tập về nhà buổi 7", testDate: "2023-04-20", test15p: 7, homework5: 8, homework4: 9, homework3: 6, homework2: 7, homework1: 9 },
{ title: "Bài tập về nhà buổi 8", testDate: "2023-06-01", test15p: 9, homework5: 9, homework4: 8, homework3: 8, homework2: 7, homework1: 10 },
{ title: "Kiểm tra 15 phút - Đợt 5", testDate: "2025-08-01", test15p: 8, homework5: 9, homework4: 10, homework3: 7, homework2: 6, homework1: 8 },
{ title: "Bài tập về nhà buổi 9", testDate: "2023-05-05", test15p: 7, homework5: 8, homework4: 9, homework3: 6, homework2: 7, homework1: 9 },
{ title: "Bài tập về nhà buổi 10", testDate: "2023-07-01", test15p: 9, homework5: 9, homework4: 8, homework3: 8, homework2: 7, homework1: 10 },
];

// Hàm xác định trạng thái của bài tập (Còn Hạn hoặc Hết Hạn)
const getStatus = (testDate) => {
const currentDate = new Date();
const expirationDate = new Date(testDate);
return currentDate > expirationDate ? 'Hết Hạn' : 'Còn Hạn';
};

// Sắp xếp dữ liệu theo trạng thái (Còn Hạn hoặc Hết Hạn)
const sortedData = [...data].sort((a, b) => {
const statusA = getStatus(a.testDate);
const statusB = getStatus(b.testDate);




// Nếu trạng thái giống nhau, không thay đổi thứ tự
if (statusA === statusB) {
  return 0;
}

// Sắp xếp theo thứ tự "asc" hoặc "desc"
return sortOrder === "asc" ? (statusA === "Còn Hạn" ? -1 : 1) : (statusA === "Còn Hạn" ? 1 : -1);
});

// Hàm đổi thứ tự sắp xếp
const toggleSortOrder = () => {
setSortOrder((prev) => (prev === "asc" ? "desc" : "asc")); // Chuyển đổi giữa "asc" và "desc"
};

// Hàm lọc dữ liệu theo từ khóa tìm kiếm
const filteredData = sortedData.filter((row) => {
return row.title.toLowerCase().includes(searchQuery.toLowerCase()); // Kiểm tra nếu tiêu đề bài tập có chứa từ khóa tìm kiếm
});

return (
<div className="testslist-body">
<div className="sidebar">
<div className="logo">
<img src="images/logo.jpg" alt="Logo" className="logo-image" />
</div>
<div className="settings-icon">
<FaCog className="function-icon" />
</div>
<div className="function-icons">
<Link to="/addnewtest1" className="icon-item active">
<FaBook className="function-icon" />
<p className="icon-description">Môn học</p>
</Link>
<Link to="/support" className="icon-item">
<FaHeadset className="function-icon" />
<p className="icon-description">Hỗ trợ</p>
</Link>
<div className="icon-item" onClick={toggleNotifications}>
<FaBell className="function-icon" />
<p className="icon-description">Thông báo</p>
</div>
<Link to="/logout" className="icon-item">
<FaSignOutAlt className="function-icon" />
<p className="icon-description">Đăng xuất</p>
</Link>
</div>
</div>


  <div className="main-content">
    <div className="header">
      <h1 className="title">Bài tập - 4A1</h1>

      {/* Ô tìm kiếm */}
      <div className="search-wrapper">
        <input
          type="text"
          className="search-input"
          placeholder="Tìm kiếm theo tiêu đề"
          value={searchQuery} // Liên kết với state tìm kiếm
          onChange={(e) => setSearchQuery(e.target.value)} // Cập nhật giá trị tìm kiếm
        />
        <FaCog className="search-icon" />
      </div>
    </div>

    {/* Bảng bài tập */}
    <div className="table-container">
      <table className="table-kho-de">
        <thead>
          <tr>
            <th
              onClick={toggleSortOrder}
              style={{ cursor: "pointer", display: "flex", alignItems: "center" }}
            >
              Trạng Thái
              <span className={`triangle ${sortOrder === "asc" ? "triangle-down" : "triangle-up"}`}></span>
            </th>
            <th>Tiêu Đề</th>
            <th style={{ display: "flex", alignItems: "center" }}>Ngày Hết Hạn</th>
            <th>Thời Gian Làm Bài</th>
            <th>Số Câu</th>
            <th>Điểm Số</th>
          </tr>
        </thead>
        <tbody>
          {/* Duyệt qua các dữ liệu đã lọc */}
          {filteredData.map((row) => {
            const averageScore = (
              (row.test15p + row.homework5 + row.homework4 + row.homework3 + row.homework2 + row.homework1) / 6
            ).toFixed(2);
            const status = getStatus(row.testDate);
            return (
              <tr key={row.title}>
                <td style={{ color: status === 'Hết Hạn' ? '#8E0505' : '#41D052' }}>{status}</td>
                <td>{row.title}</td>
                <td>{row.testDate}</td>
                <td>{`${row.test15p} phút`}</td>
                <td>{6}</td>
                <td>{averageScore}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>

    {/* Phân trang */}
    <div className="pagination">
      <button className="page-btn active">1</button>
      <button className="page-btn">2</button>
      <button className="page-btn">3</button>
      <span className="dots">...</span>
      <button className="page-btn">6</button>
    </div>
  </div>

  {/* Hộp thông báo */}
  <div className={`notification-box ${showNotifications ? "show" : "hide"}`}>
    <div className="notification-header">
      <span>Thông Báo</span>
      <FaTimes className="close-btn" onClick={toggleNotifications} />
    </div>
    <div className="notification-content">
      {notifications.length > 0 ? (
        notifications.map((item) => (
          <div className="notification-item" key={item.id}>
            <span className="user-icon"></span>
            <div className="notification-text">
              <strong>{item.name}</strong>
              <p>{item.message}</p>
            </div>
            <FaEllipsisV className="notification-options" />
          </div>
        ))
      ) : (
        <p>Không có thông báo mới.</p>
      )}
    </div>
  </div>
</div>
);
};

export default TestsList;

