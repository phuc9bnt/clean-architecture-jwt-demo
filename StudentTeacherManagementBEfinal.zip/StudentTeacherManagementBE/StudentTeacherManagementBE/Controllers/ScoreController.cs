﻿using BusinessLogic.Interface;
using BusinessLogic.UseCase;
using CoreEntities.Models;
using CoreEntities.Models.Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors.Infrastructure;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Runtime.CompilerServices;

namespace StudentTeacherManagementBE.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize (Roles = "TEACHER")]
    public class StudentScoreController : ControllerBase
    {
        private readonly IScoreService _ScoreService;

        public StudentScoreController(IScoreService studentScoreService)
        {
            _ScoreService = studentScoreService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllScores()
        {
            var scores = await _ScoreService.GetAllScoresAsync();
            return Ok(scores);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateScore(Guid id, [FromBody] Score studentScore)
        {
            if (studentScore.ID != id)
            {
                return BadRequest("Score ID mismatch.");
            }

            try
            {
                await _ScoreService.UpdateScoreAsync(studentScore);
                return NoContent(); // 204 No Content
            }
            catch (KeyNotFoundException)
            {
                return NotFound("Score not found.");
            }
        }

        [HttpGet("student-scores")]
        public async Task<ActionResult<List<StudentScoreDto>>> GetStudentScores()
        {
            // Gọi phương thức lấy điểm
            var scores = await _ScoreService.GetStudentScoresAsync();

            // Kiểm tra kết quả
            if (scores == null || scores.Count == 0)
            {
                return NotFound("No scores found.");
            }

            return Ok(scores); // Trả về danh sách điểm
        }
    }
}
