﻿using BusinessLogic.Interface;
using BusinessLogic.Repository;
using CoreEntities.Models;
using CoreEntities.Models.Common;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlServerPlugin
{
    public class ScoreRepository : IScoreRepository
    {   
        private readonly CustomDBContext _dbContext;

        public ScoreRepository(CustomDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IEnumerable<Score>> GetAllScoresAsync()
        {
            return await _dbContext.Scores
                .Include(s => s.Student)  // Bao gồm thông tin học sinh
                .ToListAsync();
        }

        public async Task<Score> GetScoreByIdAsync(int id)
        {
            return await _dbContext.Scores.FindAsync(id);
        }

        public async Task UpdateScoreAsync(Score studentScore)
        {
            _dbContext.Scores.Update(studentScore);
            await _dbContext.SaveChangesAsync();
        }

        public async Task<Score> GetScoreByIdAsync(Guid id)
        {
            return await _dbContext.Scores.FindAsync(id);
        }

        public async Task<List<StudentScoreDto>> GetStudentScoresAsync()
        {
            var scores = await _dbContext.StudentAnswers
                .Include(sa => sa.Students)
                .Include(sa => sa.Answers)
                    .ThenInclude(a => a.Questions)
                .Select(sa => new StudentScoreDto
                {
                    StudentId = sa.StudentID,
                    StudentName = sa.Students.Name,
                    AnswerId = sa.AnswerID,
                    QuestionContent = sa.Answers.Questions.Content,
                    IsCorrect = !sa.Answers.Incorrect
                })
                .ToListAsync();

            // Tính điểm (giả sử mỗi câu trả lời đúng là 1 điểm)
            var studentScores = scores
                .GroupBy(s => new { s.StudentId, s.StudentName })
                .Select(g => new StudentScoreDto
                {
                    StudentId = g.Key.StudentId,
                    StudentName = g.Key.StudentName,
                    Score = g.Count(s => s.IsCorrect) // Tổng số câu trả lời đúng
                })
                .ToList();

            return studentScores;   
        }


    }
}

