﻿using BusinessLogic.Interface;
using BusinessLogic.Repository;
using CoreEntities.Models;
using CoreEntities.Models.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.UseCase
{
    public class ScoreService : IScoreService
    {
        private readonly IScoreRepository _repository;

        public ScoreService(IScoreRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<Score>> GetAllScoresAsync()
        {
            return await _repository.GetAllScoresAsync();
        }

        public async Task<Score> GetScoreByIdAsync(int id)
        {
            return await _repository.GetScoreByIdAsync(id);
        }

       

        
        public async Task UpdateScoreAsync(Score studentScore)
        {
            var score = await _repository.GetScoreByIdAsync(studentScore.ID);
            if (score == null)
            {
                throw new KeyNotFoundException("Score not found.");
            }

            score.StartTime = studentScore.StartTime;
            score.EndTime = studentScore.EndTime;
            score.Status = studentScore.Status;
            score.StudentID = studentScore.StudentID;
            score.QuizID = studentScore.QuizID;

            await _repository.UpdateScoreAsync(score);
        }

        public async Task<List<StudentScoreDto>> GetStudentScoresAsync()
        {
            var scores = await _repository.GetStudentScoresAsync(); // Lấy dữ liệu từ repository
            var studentScores = scores
                .GroupBy(s => new { s.StudentId, s.StudentName })
                .Select(g => new StudentScoreDto
                {
                    StudentId = g.Key.StudentId,
                    StudentName = g.Key.StudentName,
                    Score = g.Count(s => s.IsCorrect) // Tổng số câu trả lời đúng
                })
                .ToList();

            return studentScores;
        }

    }
}
