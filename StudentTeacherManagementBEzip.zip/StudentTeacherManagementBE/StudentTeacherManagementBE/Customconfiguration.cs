﻿namespace StudentTeacherManagement
{
    public class Customconfiguration
    {
        public string? ConnectionStrings { get; set; }
    }
}